from os import system
system("cls")

for i in range(4):
    print(f"Ciclo {i}")

#Realizar el mismo ciclo anterior comenzando con valor inicial de 9

for i in range(9,13):
    print(f"Ciclo {i-9}")