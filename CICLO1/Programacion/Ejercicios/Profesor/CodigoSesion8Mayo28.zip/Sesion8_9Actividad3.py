from os import system
system("cls")

n=4
conPositivo=0
conNeutros=0
conNegativos=0
for i in range(n):
    num=int(input("Digite el número: "))
    if (num>0):
        conPositivo+=1
    elif (num==0):
        conNeutros+=1
    else:
        conNegativos+=1
        
print(f"Los positivos son: {conPositivo}")    
print(f"Los negativos son: {conNegativos}")   
print(f"Los neutros son: {conNeutros}")   