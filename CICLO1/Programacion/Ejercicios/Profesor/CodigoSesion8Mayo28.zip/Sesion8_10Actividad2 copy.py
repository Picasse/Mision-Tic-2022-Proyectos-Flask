from os import system
system("cls")

palabra=input("Digite la palabra: ")

print(f"La palabra {palabra} tiene {len(palabra)}")
n=len(palabra)
for i in range(n):
    if (palabra[i]=="a" or palabra[i]=="A"):
        break
    print(palabra[i])
