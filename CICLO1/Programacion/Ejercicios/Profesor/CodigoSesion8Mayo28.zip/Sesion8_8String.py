from os import system
system("cls")

cad="HolaMUndo"

print(f"La longitud de la cadena es: {len(cad)}")

for i in range(len(cad)):
    print(cad[i])


    


