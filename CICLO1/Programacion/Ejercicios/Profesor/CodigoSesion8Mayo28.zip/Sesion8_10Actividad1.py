from os import system
system("cls")

n=int(input("Ingrese la cantidad de valores de la serie a imprimir: "))

primero=0
segundo=1
suma=0

for i in range(n):
    print(suma)
    primero=segundo
    segundo=suma
    suma=primero+segundo