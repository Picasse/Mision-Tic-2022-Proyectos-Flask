from os import system
system("cls")

n=int(input("Digite cuantos Holas quiere imprimir: "))
print("--- Sin Valor Inicial----")
for i in range(n):
    print(i)
    
print("--- Con valor inicial ---")
for i in range(2,n):
    print(i)

print("-- Con valor inicial y paso --")
for i in range(2,n,2):
    print(i)

for i in range(4):
    print(f"Ciclo {1}")