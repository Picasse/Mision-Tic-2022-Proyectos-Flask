#Imprimir los numeros pares e impares hasta un valor
#dado por el usuario y comenzando en 20 utilizando un solo ciclo for
#Debe colocar al lado la palabra par o impar
from os import system
system("cls")

n=int(input("Digite un valor mayor de 20: "))

for i in range(20,n+1,2):
    print(f"{i} - par")
    print(f"{i+1}- impar")


