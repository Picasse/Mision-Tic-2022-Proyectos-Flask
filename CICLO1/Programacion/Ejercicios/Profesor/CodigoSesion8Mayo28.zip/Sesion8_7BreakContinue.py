from os import system
system("cls")
print("--Break")
n=20
for i in range(2,n):
    if (i==13):
        break
    print(i)

print("--Continue") 
for i in range(2,n):
    if (i==13):
        continue
    print(i)




