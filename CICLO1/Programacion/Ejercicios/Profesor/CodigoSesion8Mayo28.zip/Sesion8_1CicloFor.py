from os import system
system("cls")

n=int(input("Digite cuantos Holas quiere imprimir: "))

for i in range(n):
    print("Hola")

