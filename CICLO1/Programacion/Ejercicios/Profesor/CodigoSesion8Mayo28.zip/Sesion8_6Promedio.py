from os import system
system("cls")

n=int(input("Digite la cantidad de estudiantes: "))
sum=0
for i in range(n):
    nota=int(input(f"Digite Nota {i+1}: "))  #el {i+1} para indicar al usurio el número de la nota que está ingresando
    sum+=nota #sum=sum+nota
prom=sum/n
print(f"El promedio de las notas es: {prom:.2f}")
    
    
