from os import system
system("cls")


for i in range(10,0,-1):
    print(i)
    