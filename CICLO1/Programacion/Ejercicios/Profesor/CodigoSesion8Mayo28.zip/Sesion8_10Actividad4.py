from os import system
system("cls")

numero=int(input("Ingrese el numero a obtener el factorial: "))

while (numero!=-1):
    if(numero<0):
        print("Factorial de Negativos no existe")
    elif numero==0:
        print("1")
    else:
        factorial=1
        for i in range(1,numero+1):
            factorial=factorial*i #factorial*=i
        print(f"El facorial de {numero} es {factorial}")
    
    numero=int(input("Ingrese el numero a obtener el factorial: "))
            
        
        
        
    
