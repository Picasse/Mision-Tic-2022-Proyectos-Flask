
genero=int(input("Digite genero: "))

while ((genero!=1) and (genero!=2)):
    genero=int(input("Digite genero: "))
    
