from os import system
system("cls")
print("Iniciando el bucle while")
i=1
while i<=6:
    if i==3:
        i+=1
        continue
    print(i)
    i=i+1
print("Fin de bucle")    