from os import system
system("cls")

#Imprimir los numeros del valor de i al seis
# partiendo del valor indicado en i
# el conteo se debe detener si el valor
# a imprimir es un tres

print("Iniciando el ciclo while")
i=1
while (i<6):
    print(i)
    if i==3:
        break
    i+=1
print("Continua el programa")
