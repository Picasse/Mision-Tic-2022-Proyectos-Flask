numero = int(input("Ingrese un numero: "))
num = 2

while num <= numero:
    print(num)
    if num == 10:
        break
    num = num + 2