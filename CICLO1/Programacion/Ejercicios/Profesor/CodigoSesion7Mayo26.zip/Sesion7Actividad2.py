from os import system
system("cls")

numero=int(input("INGRESE UN NUMERO:"))
temporal=numero
contador=0
residuo=0
while temporal>0:
    residuo=temporal%10
    temporal=temporal//10
    print(residuo)
    if residuo==4:
        continue
    contador+=1

print(f"El numero {numero} tiene {contador} cifras")