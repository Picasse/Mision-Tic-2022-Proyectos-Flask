from os import system
system("cls")

cantidadNotasALeer=int(input("Ingrese la cantidad de Notas: "))
cantidadNotasLeidas=1 # Alamacena la cantidad de estudiates de los que he leido notas
sumaNotas=0 #Sumatoria de las notas de los estudiantes

while (cantidadNotasLeidas<=cantidadNotasALeer):
    nota=int(input("Digite nota: "))
    sumaNotas+=nota #sumaNotas=sumaNotas+nota
    cantidadNotasLeidas+=1

promedioNotas=sumaNotas/cantidadNotasALeer

print(f"el promedio de las notas es: {promedioNotas:.2f}")
