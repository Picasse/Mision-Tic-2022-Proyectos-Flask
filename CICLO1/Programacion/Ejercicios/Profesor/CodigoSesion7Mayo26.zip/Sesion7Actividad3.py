cantidad_notas=int(input("ingresar cantidad de notas a calificar: "))
notas_leidas=1
notas_mayores=0
notas_menores=0
while(notas_leidas<=cantidad_notas):
    notas=int(input("ingresar notas: "))
    notas_leidas+=1
    if (notas<7):
        notas_menores+=1
    else:
        notas_mayores+=1
print("la cantidad de notas menores es: ", notas_menores)
print("la cantidad de notas mayores: ", notas_mayores)