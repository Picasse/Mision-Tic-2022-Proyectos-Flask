from os import system
from random import randint
system("cls")

def recorrerMatrizFila(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()

def llenarMatriz():
    matriz=[]
    for i in range(5):
        fila=[]
        for j in range(10):
            fila.append(randint(1,100))
        matriz.append(fila)
    return matriz


def mayorMenorMatriz(matriz):
    mayor=matriz[0][0]
    menor=matriz[0][0]
    posicionx=0
    posiciony=0
    for fila in matriz:
        posiciony=0
        for valor in fila:
            if valor>mayor:
                mayor=valor
                filaMayor=posicionx
                columnaMayor=posiciony
            if valor<menor:
                menor=valor
                filaMenor=posicionx
                columnaMenor=posiciony
            posiciony+=1
        posicionx+=1    
    return mayor,filaMayor,columnaMayor, menor, filaMenor,columnaMenor
    

matriz=llenarMatriz()
recorrerMatrizFila(matriz) #Esto es para ver que se generó
print("--------Resultados---------------")

resultados=mayorMenorMatriz(matriz)
print(f"El numero mayor {resultados[0]} en la posicion{resultados[1],resultados[2]}")
print(f"El numero menor {resultados[3]} en la posicion{resultados[4],resultados[5]}")

            



        