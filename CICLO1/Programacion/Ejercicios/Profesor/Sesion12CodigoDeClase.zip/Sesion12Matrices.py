from os import system
system("cls")

#fila1=[8,9,7]
#fila2=[12,5,3]

#matriz=[fila1,fila2]
matriz=[[8,9,7],[12,5,3]]

# print(matriz)
# print(matriz[0][0])
# print(matriz[1][1])

def recorrerMatrizFila(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()

#Imprimir una fila especifica
#print(matriz[0])
#recorrerMatrizFila(matriz)

def recorrerMatrizFilaIndices(matriz):
    for i in range(len(matriz)):
        fila=matriz[i]
        print()
        for j in range(len(fila)):
            print(matriz[i][j], end=" ")
    print()
        
#recorrerMatrizFilaIndices(matriz)     

def recorrerMatrizColumnaIndice(matriz):
    for j in range(len(matriz[0])):
        print()
        for fila in matriz:
            print(fila[j], end=" ")
    print()
    

recorrerMatrizColumnaIndice(matriz)         
            
