from os import system
from random import randint
system("cls")

def recorrerMatrizFila(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()

def matrizPorEscalar(matriz, escalar):
    nuevaMatriz=[]
    for fila in matriz:
        nueva_fila=[]
        for valor in fila:
            nueva_fila.append(valor*escalar)
        nuevaMatriz.append(nueva_fila)
    return nuevaMatriz

def llenarMatriz():
    matriz=[]
    for i in range(3):
        fila=[]
        for j in range(4):
            fila.append(randint(1,100))
        matriz.append(fila)
    return matriz

escalar = 8
matriz=llenarMatriz()
recorrerMatrizFila(matriz)
matriz2=matrizPorEscalar(matriz, escalar)
print("---El producto del escalr por la matriz es: ------")
recorrerMatrizFila(matriz2)
       