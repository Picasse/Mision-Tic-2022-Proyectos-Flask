from os import system
system("cls")

nombres=[]
edades=[]

for x in range(5):
    nom=input("Ingrese el nombre de la persona: ")
    nombres.append(nom)
    edad=int(input(f"Ingrese la edad de {nom}: "))
    edades.append(edad)

print("--- Las personas mayor de dad son: -----")
for x in range(5):
    if edades[x]>=18:
        print(nombres[x])
    

