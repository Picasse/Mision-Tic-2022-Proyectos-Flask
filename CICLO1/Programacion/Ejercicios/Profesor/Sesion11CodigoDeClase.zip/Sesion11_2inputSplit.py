from os import system
system("cls")

datos=input().split(" ")
print(datos)
edad=int(datos[0])
telefono=int(datos[1])
direc= int(datos[2])

print(edad,telefono,direc)
