from os import system
system("cls")

def operacionesListas(lista1,lista2, oper):
    total=[]
    if oper=="sumar":
        for i in range(len(lista1)):
            total.append(lista1[i]+lista2[i])
    
    if oper=="restar":
        for i in range(len(lista1)):
            total.append(lista1[i]-lista2[i])
    
    if oper=="dividir":
        for i in range(len(lista1)):
            total.append(lista1[i]/lista2[i])
    
    return total
                
def maxMinListaIndice(lista, oper):
    if oper=="min":
        minimo=min(lista)
        indice=lista.index(minimo)
        return minimo, indice
    elif oper=="max":
        maximo=max(lista)
        indice=lista.index(maximo)
        return maximo, indice
        


def main():
    #n representa la cantidad de tiendas
    #m representa los estantes por tienda
    
    canTiendasYEstan=input().split(' ')
    cantTiendas= int(canTiendasYEstan[0])
    cantEstantes= int(canTiendasYEstan[1])
    invInicialT=[]
    invSolicitadoT=[]
    for i in range(cantTiendas):
        invIni=int(input())
        invInicialT.append(invIni)
        invSolicitadoT.append(0)
    
    for i in range(cantEstantes):
        infoEstantes=input().split(' ')
        numTienda=int(infoEstantes[0])
        inventmin=int(infoEstantes[1])
        inventmax=int(infoEstantes[2])
        
        #if 0 < numTienda<=cantTiendas:
        if (numTienda>0) and (numTienda<=cantTiendas):
            if inventmin<30 and inventmax<50:
                invSolicitadoT[numTienda-1]+=20
            elif (inventmin>=30 and inventmin<50) and (inventmax>=50 and inventmax<100):
                invSolicitadoT[numTienda-1]+=30
            elif inventmin>=50 and inventmax>=100:
                invSolicitadoT[numTienda-1]+=80
    
    invFinal=operacionesListas(invInicialT,invSolicitadoT, "sumar")
    
    maxima=maxMinListaIndice(invFinal, "max")
    print(f"la tienda {maxima[1]+1} es la de mayor inventario con {maxima[0]} papas")
    minima=maxMinListaIndice(invFinal, "min")
    print(f"la tienda {minima[1]+1} es la de menor inventario con {minima[0]} papas")
    
    porcentaje=operacionesListas(invInicialT,invSolicitadoT, "dividir")
    
    for i in range(cantTiendas):
        print("{:} {:.3f}%".format(i+1, porcentaje[i]*100))
    
    invFinal.sort()
    print(invFinal)

    
    
        
        
    
              
            
main()          
            
            
            
        
            
        
        
    