from os import system
system("cls")


def actividad1(oracion,n):
    frase=oracion.split()
    palabras=[]
    for word in frase:
        if (len(word)>n):
            palabras.append(word)
    return palabras
        
oracion="la programacion es muy importante para el desarrollo de la ciencia"       
palabras=actividad1(oracion,3)
print(palabras)    
