from os import system
from random import randint
system("cls")

def recorrerMatriz(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()
    
def llenarMatrizAleatorios(fila, columna):
    matriz=[]
    for i in range(fila):
        fila=[]
        for j in range(columna):
            fila.append(randint(0,9))
        matriz.append(fila)
    return matriz

def calcularPromedio(T):
    suma=0
    numElementos=0
    for i in range(len(T)):
        for j in range(len(T[i])):
            suma+=T[i][j]
            numElementos+=1
    
    promedio=suma/numElementos
    return promedio

def matrizDeUnos(matriz,promedio):
    nuevamatriz=[]
    for i in range(len(matriz)):
        fila=[]
        for j in range(len(matriz[0])):
            if matriz[i][j]>=promedio:
                fila.append(1)
            else:
                fila.append(0)            
        nuevamatriz.append(fila)
    return nuevamatriz
    
    
             
matriz=llenarMatrizAleatorios(4,3)
recorrerMatriz(matriz)
promedio=calcularPromedio(matriz)
print(f"el promedio es: {promedio}")
matrizUnos=matrizDeUnos(matriz,promedio)
recorrerMatriz(matrizUnos)

