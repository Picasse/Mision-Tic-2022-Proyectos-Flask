def cuadrado(num1):
    print(f"El cuadrado es: {num1*num1}")
    
def sumar(num1, num2):
    print(f"El valor de num1 es: {num1} y el valor de num2 es: {num2}")
    print(f"La Suma es: {num1+num2}")


cuadrado(7)
sumar(7,5)

    