from os import system
system("cls")

def multiplicar(val1, val2, val3):
    #total = val1 * val2 * val3
    return  val1 * val2 * val3

resultado=multiplicar(5,60,2)
print(resultado)
