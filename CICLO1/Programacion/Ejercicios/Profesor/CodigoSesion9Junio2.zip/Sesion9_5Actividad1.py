def imprimaProducto(nombre, precio):
    print(f"Producto: {nombre} Precio: {precio}")

def caja():
    nombre=input("Ingrese el nombre del artículo: ")
    precio=int(input(f"Ingrese el precio de: {nombre}: "))
    total=precio
    imprimaProducto(nombre,precio)
    continuar=True
    while continuar:
        cont=input("Desea continuar e ingresar más artículos? (Si o No: ")
        if (cont=="Si"):
            nombre=input("Ingrese el nombre del artículo: ")
            precio=int(input(f"Ingrese el precio de: {nombre} "))
            total+=precio
            imprimaProducto(nombre,precio)
        else:
            continuar=False
            #break
    print(f"El total de la compra es: {total}")

caja()
            
        
