from os import system
system("cls")

def factorial(numero):
    factorial=1
    for i in range(1,numero+1):
        factorial=factorial*i #factorial*=i
    return factorial

n=int(input("Ingrese el tamaño del conjunto: "))
m= int(input("Tamaño de grupos a crear: "))

nf=factorial(n)
mf=factorial(m)
nmf=factorial(n-m)
combinacion=nf/(mf*nmf)

print(f"La cantidad de combinaciones es : {combinacion}")


