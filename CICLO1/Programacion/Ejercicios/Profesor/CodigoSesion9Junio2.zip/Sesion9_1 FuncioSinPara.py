def imprimir_Mensaje():
    print("La clase está muy interesante")
    print("Python es muy sencillo y potente")

def mensajeFeliz():
    print("Feliz Día")

def repetirMensajes():
    imprimir_Mensaje()
    imprimir_Mensaje()
    mensajeFeliz()
    
repetirMensajes()




