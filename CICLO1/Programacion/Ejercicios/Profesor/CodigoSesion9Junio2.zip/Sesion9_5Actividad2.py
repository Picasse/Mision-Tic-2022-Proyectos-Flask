from os import system
from random import randint
system("cls")

def numAleatorio():    
    while True:
        num= randint(100,130)        
        if num!=110 and num!=115 and num!=120:
            break
    return num
        
def numeros():
    cont=1
    while cont<=10:      
        if (cont%2!=0):#contadores impares numeros pares 
            while True:
                numi=numAleatorio()
                if (numi%2==0):                    
                    break                       
        else: #contadores pares numeros impares           
            while True:
                numi=numAleatorio()
                if (numi%2==1):                    
                    break
        print(numi)
        cont+=1    
        
    
numeros()


