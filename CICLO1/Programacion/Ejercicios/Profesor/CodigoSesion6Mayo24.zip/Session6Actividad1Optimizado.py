from os import system
system("cls") #para Linux y creo que Mac es clear

num=int(input("Digite un número: "))
avance=2
while (avance<=num):    
    print(avance)
    avance+=2 
  

