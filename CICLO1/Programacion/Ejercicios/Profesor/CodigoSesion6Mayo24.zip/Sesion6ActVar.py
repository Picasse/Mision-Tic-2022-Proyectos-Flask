x=25
x=x+1
print(x)