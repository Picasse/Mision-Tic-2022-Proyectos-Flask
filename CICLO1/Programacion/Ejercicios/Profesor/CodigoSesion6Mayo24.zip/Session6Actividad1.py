from os import system
system("cls") #para Linux y creo que Mac es clear

num=int(input("Digite un número: "))
avance=2
while (avance<=num):
    if(avance%2==0):
        print(avance)
    avance+=1 
  

