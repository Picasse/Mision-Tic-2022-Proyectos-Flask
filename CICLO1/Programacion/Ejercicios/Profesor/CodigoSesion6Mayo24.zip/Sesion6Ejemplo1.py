#Esto no es necesario para el código sólo
#es para limpiar pantalla
from os import system
system("cls")


i=1
while i<=3:
    print(i)
    i+=1 #i=i+1
print("El programa ha terminado")
  