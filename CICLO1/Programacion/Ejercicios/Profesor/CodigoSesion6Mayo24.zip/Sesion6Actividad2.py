from os import system
system("cls")

#El numero 256 tiene 3 digitos

num=int(input("Digite un número: "))
temporal=num
cont=0
while (temporal>0):
    temporal=temporal//10
    cont+=1

print(f"El numero {num} tiene {cont} cifras")

