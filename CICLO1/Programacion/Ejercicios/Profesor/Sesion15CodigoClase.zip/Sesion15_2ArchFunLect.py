def funReadLines():
    archivo=open('archivop1.txt','r')
    info=archivo.readlines()
    print(info)

#funReadLines()

def funRead():
    archivo=open("archivop1.txt", "r")
    info=archivo.read()
    print(info)

#funRead()

def funReadLine():
    archivo=open('archivop1.txt','r')
    linea=archivo.readline()
    print(linea)
    linea=archivo.readline()
    print(linea)

funReadLine()