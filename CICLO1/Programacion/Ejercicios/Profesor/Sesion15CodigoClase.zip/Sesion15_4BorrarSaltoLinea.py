archivo=open("archivop1.txt","r")
lineas=[]

for linea in archivo:
    lineas.append(linea.rstrip(' \n'))

archivo.close()

print(lineas)