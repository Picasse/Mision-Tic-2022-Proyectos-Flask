from os import system
from random import randint
system("cls")

def recorrerMatriz(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()
    
def indicadores(matrizAsignacion, matrizRegistro):
    matrizCamion=[]
    #Se va a almacenar 
    # NumeroCamion NumeroPuntos Eficiencia TasaEntrega Cumplimiento
    for i in range(5):
        matrizCamion.append([i+1,0,0,0,0])
    #Se asume matriz de asignacion del mismo tamaño
    #que la matriz de registro
    for i in range(len(matrizAsignacion)):
        eficiencia=((matrizRegistro[i][3])/(matrizAsignacion[i][3]))*100
        tasaEntrega=((matrizRegistro[i][2])/(matrizRegistro[i][3]))
        cumplimiento=((matrizRegistro[i][2])/matrizAsignacion[i][2])*100
        
        for j in range(len(matrizCamion)):
            if matrizCamion[j][0]==matrizAsignacion[i][1]:
                matrizCamion[j][1]=matrizCamion[j][1]+1
                matrizCamion[j][2]=matrizCamion[j][2]+eficiencia
                matrizCamion[j][3]=matrizCamion[j][3]+tasaEntrega
                matrizCamion[j][4]=matrizCamion[j][4]+cumplimiento
    #Calcular los promedios dependiendo del numero de puntos por camion
    for i in range(len(matrizCamion)):
        matrizCamion[i][2]=(matrizCamion[i][2])/(matrizCamion[i][1])
        matrizCamion[i][3]=(matrizCamion[i][3])/(matrizCamion[i][1])
        matrizCamion[i][4]=(matrizCamion[i][4])/(matrizCamion[i][1])
    return matrizCamion
    
  
def main():
    matrizAsignacion=[[1,5,1329,10], [2,4,2,35], [3,1,1462,54], [4,3,1222,35], [5,2,2000,44],[6,3,1389,52], [7,1,1500,35],
    [8,1,1419,50], [9,5,1355,44], [10,4,1000,36]]  
    matrizRegistro=[[1,5,1168,52], [2,4,1224,51], [3,1,1379,33], [4,3,1281,52], [5,2,1200,38], [6,3,1320,34],
    [7,1,1225,52], [8,1,1149,51], [9,5,1424,34], [10,4,1000,36]] 
    
    recorrerMatriz(matrizAsignacion)
    recorrerMatriz(matrizRegistro)
    matrizCamion=indicadores(matrizAsignacion, matrizRegistro)
    recorrerMatriz(matrizCamion)
        
main()