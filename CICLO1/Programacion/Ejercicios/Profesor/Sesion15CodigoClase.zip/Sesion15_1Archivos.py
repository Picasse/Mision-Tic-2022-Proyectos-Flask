#archivo=open("archivop1.txt","r")
#archivo=open("archivop1.txt","w")
#archivo=open("archivop1.txt","a")

#archivo=open("archivop1.txt","r+")
#archivo=open("archivop1.txt","a+")
archivo=open("archivop1.txt","w+")
archivo.close()