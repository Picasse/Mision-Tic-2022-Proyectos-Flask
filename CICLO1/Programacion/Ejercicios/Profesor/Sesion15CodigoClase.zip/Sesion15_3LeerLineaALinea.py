archivo=open('archivop1.txt', 'r')
lineas=[]

for linea in archivo:
    lineas.append(linea) 

archivo.close()
print(lineas)