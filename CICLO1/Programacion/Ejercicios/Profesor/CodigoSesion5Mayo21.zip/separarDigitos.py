#0. Obtener los dígitos de un número leido
num = input("Digite un número")
dig1=num[0]
dig2=num[1]
dig3=num[2]
dig4=num[3]

print(dig3)