luz_sema=input("Digite la luz del semaforo (Verde/Amarillo/Rojo): ")
if (luz_sema=="Verde" or luz_sema=="verde"):
    print("Siga")
elif (luz_sema=="Amarilla"):
    print("Precaución")
elif (luz_sema=="Roja"):
    print("Pare") 
else:
    print("Entrada Invalida")
    
    
 