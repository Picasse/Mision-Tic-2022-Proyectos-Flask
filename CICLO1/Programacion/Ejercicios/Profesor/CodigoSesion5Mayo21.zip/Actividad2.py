luz_sema=input("Digite la luz del semaforo (Verde/Amarilla/Roja): ")

if (luz_sema=="Verde"):
    peaton=input("Hy peaton (Si/No): ")
    if (peaton=="Si"):
        print("Pare")
    else:  
        print("Siga")
elif (luz_sema=="Amarilla"):
    peaton=input("Hy peaton (Si/No): ")
    if (peaton=="Si"):
        print("Pare")
    else:  
        print("Precaución")
    
elif (luz_sema=="Roja"):
    print("Pare") 
else:
    print("Entrada Invalida")
    
    
 