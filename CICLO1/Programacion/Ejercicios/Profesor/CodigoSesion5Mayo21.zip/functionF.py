var=2500
#print("El valor de su compra es de:",var)
#Concatenando

print("El valor de su compra es de:"+str(var)+" Gracias por su compra")


print(f"El valor de su compra es de: {var} Gracias por su compra")
