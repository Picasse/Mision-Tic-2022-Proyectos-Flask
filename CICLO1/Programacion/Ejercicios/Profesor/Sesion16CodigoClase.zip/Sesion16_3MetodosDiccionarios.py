diccionario4={
    "total":55+23, 
    "descuento":{
        "navidad":30,
        "verano":10        
    }, 
    15:"Kla",
    "secuencia":[25,36,45] 
  
}

#print(diccionario4)
#diccionario4.clear()
#diccionario5=diccionario4.copy()
#print(diccionario4.get('secuencia'))
#print(diccionario4.has_key('secuencia')) has_key fue descontinuado
#print(diccionario4.items())
#diccionario4.pop('secuencia')
#print(len(diccionario4))

for clave in diccionario4:
    print(clave)

for clave,valor in diccionario4.items():
    print(clave,valor)
