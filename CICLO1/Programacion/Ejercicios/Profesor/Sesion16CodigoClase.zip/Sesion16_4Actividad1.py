from os import system
system("cls")

def recorrerMatriz(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()
    

def leerMatrizAsignacion():
    matrizAsignacion=[]
    archivoMatriz=open("matrizAsignacion.txt",'r')
    
    for linea in archivoMatriz:
        lineasb=linea.rstrip("\n")
        fila=lineasb.split(',')
        matrizAsignacion.append(fila)
    
    archivoMatriz.close()
    
    return matrizAsignacion

def escribirMatriz(matriz):
    f=open("archivoEscribirMatriz.txt","w")
    for fila in matriz:
        f.writelines(fila)
        f.write("\n")
    f.close()

def escribirMatriz2(matriz):
    f=open("archivoEscribirMatriz2.txt","w")
    for fila in matriz:
        for valor in fila:
            f.write(valor)
            f.write(" ")
        f.write("\n")       
    
    f.close()
          

mA=leerMatrizAsignacion()
recorrerMatriz(mA)
escribirMatriz2(mA)

    
    
        