from os import system
system("cls")

# diccionario=dict()
# print(diccionario)
diccionarioVacio={}
diccionario1={"total":55}
diccionario2={"total":55, "descuento":True, 15:"2558"}
diccionario3={"total":55+23, "descuento":True, 15:"Kla"}

diccionario4={
    "total":55+23, 
    "descuento":{
        "navidad":30,
        "verano":10        
    }, 
    15:"Kla",
    "secuencia":[25,36,45] 
  
}
#print(diccionario4['descuento']["verano"])
print(diccionario4)
diccionario4['punto']="Centro"
diccionario4['total']=20
print(diccionario4.keys())
print(diccionario4.values())
print(diccionario4["secuencia"][1])

#Operador in

valor='total2' in diccionario4
print(valor)




