#Write

linea="HolaMundo2"
f=open("archivoWrite.txt","a")
f.write("\n")
f.write(linea)
f.close()

lista=["linea 1\n","linea 2\n"]
f=open("archivoMultilinea.txt","a")
f.writelines(lista)
f.close()