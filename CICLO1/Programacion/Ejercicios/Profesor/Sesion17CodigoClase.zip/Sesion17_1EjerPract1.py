file=open("personas.txt","r",encoding="utf-8-sig")
datosPersonas=[]
for linea in file:
    pal=linea.split(";")
    elemento={
        "id":pal[0],
        "nombre":pal[1],
        "apellido":pal[2],
        "nacimiento":pal[3]
    }
    datosPersonas.append(elemento)

file.close()
print(datosPersonas)
    

