try:
    file=open("contador.txt","r+")
    dato=file.readline()
    if dato=="":
        file.write('0') 
        dato=0      
except FileNotFoundError:
    file=open("contador.txt","w")
    file.write("0")
    dato=0

op=""

while op!="sal":
    op=input("Desea incrementar(inc), decrementar(dec) o salir(sal)")
    if op=="inc":
        inc=int(dato)+1
        print(inc)
        file.seek(0)
        file.truncate()
        file.write(str(inc))
    elif op=="dec":
        dec=int(dato)-1
        print(dec)
        file.seek(0)
        file.truncate()
        file.write(str(dec))
    elif op=="sal":
        print("Muchas gracias")
    else:
        print(f"Opcion no valida. El valor del contador está en: {dato}")
       
    file.seek(0)
    dato=file.readline()

file.close()      