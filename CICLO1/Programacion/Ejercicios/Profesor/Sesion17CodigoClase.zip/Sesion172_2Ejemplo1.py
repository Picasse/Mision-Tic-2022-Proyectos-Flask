import csv

def testCSV():
    archivo =  open('matrizAsignacion.csv', mode='r', encoding='utf-8-sig' ) 
    lector = csv.reader(archivo,delimiter=";") #Retorna un objeto con las filas del csv
    
    
    for fila in lector: #Este va a recorrer cada fila
        print(fila)
        for i in fila:  #Este recorre cada valor en cada fila [i] representa cada elemento separado por ,
             print(i)

testCSV()
