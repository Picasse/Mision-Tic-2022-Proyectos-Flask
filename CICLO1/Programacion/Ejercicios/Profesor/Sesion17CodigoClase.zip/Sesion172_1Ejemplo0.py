def leerARchivo():   
    with open("personas.csv","r", encoding="utf-8-sig") as datafile:
        linea=datafile.readline()
        encabezado=linea.rstrip("\n").split(",")
        matriz=[]
        linea=datafile.readline()
        while linea:
            fila=linea.rstrip("\n").split(",")
            matriz.append(fila)
            linea=datafile.readline()
    return encabezado, matriz

datos=leerARchivo()
print(datos[0])
print(datos[1])


    
            
            
        