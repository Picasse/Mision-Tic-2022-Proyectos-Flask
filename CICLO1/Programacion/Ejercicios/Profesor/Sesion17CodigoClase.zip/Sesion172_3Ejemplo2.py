import csv

def testIOcsv():
    archivo =  open('matrizAsignacion.csv', mode='r', encoding='utf-8-sig' ) 
    
    nuevoArchivo = open('archivoResultado.csv', mode='w', encoding='utf-8-sig' )
    
    lector = csv.reader(archivo) #Retorna un objeto con las filas del csv para ser leidas
     
    escritor = csv.writer(nuevoArchivo) #Retorna un objeto para escribir en csv
    
    for fila in lector: #Este va a recorrer cada fila del lector (Trabaja como una lista)
        fila.append("Nuevo")
        escritor.writerow(fila) # Este escribe cada fila en

testIOcsv()
