from os import system
from random import randint
system("cls")

def llenarMatrizAleatorios(fila, columna):
    matriz=[]
    for i in range(fila):
        fila=[]
        for j in range(columna):
            fila.append(randint(1,100))
        matriz.append(fila)
    return matriz

def llenarMatrizLeyendoElemento(fila, columna):
    matriz=[]
    for i in range(fila):
        fila=[]
        for j in range(columna):
            fila.append(input(f"Fila {i} columna {j}: "))
        matriz.append(fila)
    return matriz

def llenarMatrizLeyendoFila(filas):
    matriz=[]
    for i in range(filas):
        datos=input("digite la fila de la matriz: ").split(" ")
        fila=[]        
        for j in range(len(datos)):
            fila.append(int(datos[j]))
        matriz.append(fila)
    return matriz

def recorrerMatriz(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()


def obtenerColumnaMatriz(matriz, col):
    columna=[]
    for i in range(len(matriz)):
        valor=[matriz[i][col]]        
        columna.append(valor)
    return columna

def obtenerFilaMatriz(matriz, fil):
    fila=[]
    for j in range(len(matriz[0])):
        valor=[matriz[fil][j]]        
        fila.append(valor)
    return fila
    
    
matriz=llenarMatrizAleatorios(3,3)
recorrerMatriz(matriz)
columna=obtenerColumnaMatriz(matriz,1)
recorrerMatriz(columna)
fila=obtenerFilaMatriz(matriz,0)
recorrerMatriz(fila)
print(matriz[0])
print(matriz[1][1])

#print(matriz[0][0],matriz[0][1],matriz[0][2])
#print(matriz[0][0],matriz[1][0],matriz[2][0])


