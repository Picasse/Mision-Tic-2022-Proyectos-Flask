from os import system
from random import randint
system("cls")

def llenarMatriz(fila, columna):
    matriz=[]
    for i in range(fila):
        fila=[]
        for j in range(columna):
            fila.append(randint(1,100))
        matriz.append(fila)
    return matriz

def recorrerMatriz(matriz):
    for fila in matriz:
        print()
        for valor in fila:
            print(valor, end=" ")
    print()


def diagonalMatriz(matriz):    
    if len(matriz)==len(matriz[0]): #Se verifica si la matriz es cuadrada
        listaDiagonal=[]
        for i in range(len(matriz)):        
            for j in range(len(matriz[i])):
                if i==j:
                    listaDiagonal.append(matriz[i][j])
        return listaDiagonal
    else:
        print("La matriz no es cuadrada")

def diagonalMatrizOptimizada(matriz):    
    if len(matriz)==len(matriz[0]): #Se verifica si la matriz es cuadrada
        listaDiagonal=[]
        for i in range(len(matriz)):
            listaDiagonal.append(matriz[i][i])
        return listaDiagonal
    else:
        print("La matriz no es cuadrada")



matriz=llenarMatriz(5,5)
recorrerMatriz(matriz)
diagonal=diagonalMatriz(matriz)
print(diagonal)

diagonal2=diagonalMatrizOptimizada(matriz)
print(diagonal2)