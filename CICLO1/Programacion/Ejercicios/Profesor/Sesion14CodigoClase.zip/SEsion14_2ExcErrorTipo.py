from os import system
system("cls")

def aumentar(num,num2):
    return num/num2

# res=aumentar(5)
# print(res)

try:
    res=aumentar(5,0)
    print(res)  
except TypeError:
    print("El argumento dado no es valido")
except ZeroDivisionError:
    print("División entre cero")