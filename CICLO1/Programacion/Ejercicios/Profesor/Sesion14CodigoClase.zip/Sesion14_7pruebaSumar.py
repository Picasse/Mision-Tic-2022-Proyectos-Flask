import unittest
import sesion14_7Sumar

class TestMiModulo(unittest.TestCase):
    def test_sum(self):
        self.assertEqual(sesion14_7Sumar.suma(5,7),12)


unittest.main()