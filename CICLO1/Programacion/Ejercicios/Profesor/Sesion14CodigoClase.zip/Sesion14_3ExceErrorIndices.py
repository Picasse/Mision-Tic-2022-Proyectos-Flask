lista=["hola",2,3.5,True]

try:
    print(lista[2])
except IndexError:
    print("Indice fuera del rango")
    