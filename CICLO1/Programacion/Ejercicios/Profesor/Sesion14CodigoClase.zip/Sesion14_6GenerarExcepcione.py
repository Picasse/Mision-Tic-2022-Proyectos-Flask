from os import system
system("cls")

x=-1
if x<0:
    raise Exception("El numero es menor de cero")

x="hello"
if not type(x) is int:
    raise TypeError("Solamente enteros permitidos")

