from os import system
system("cls")

def dividir(num,div):
    return num/div

# res=dividir(10,2)
# print(res)

try:
    res=dividir(10,0)
    print(res)
except ZeroDivisionError:
    print("Se ha realizado una división entre cero")
    
print("Hola")
    