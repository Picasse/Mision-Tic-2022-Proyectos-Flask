from os import system
system("cls")

while True:
    try:
        x=int(input("Ingresa un número entero: "))
        break    
    except ValueError:
        print("Debe ser un numero entero")

