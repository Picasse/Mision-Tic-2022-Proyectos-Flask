import math

try:
    print(math.sqrt(-1))
except ValueError:
    print("Raiz cuadrada de numero negativo")