import unittest
from Sesion14_8practico import cuadrado, cubo, es_primo

class TestUtils(unittest.TestCase):
  def test_es_primo(self):
      self.assertTrue(es_primo(2))
      self.assertFalse(es_primo(3))
      self.assertTrue(es_primo(5))

  def test_cuadrado(self):
      self.assertEqual(cuadrado(2), 4)


if __name__ == '__main__':
    unittest.main()
