from os import system
from random import randint
system("cls")


def mayor(lista):
    return max(lista)

def primos(lista):
    print("Primos de la lista son: ")
    for elemento in lista:
        print(elemento)
        primo=True
        for j in range(2,elemento):
            if(elemento%j==0):
                primo=False
                break
        if primo:
            print(elemento)
                
                
    
def main():
    lista=[]
    for i in range(6):
        lista.append(randint(1,20))    
    print(lista)
    print(mayor(lista))
    print(primos(lista))


main()