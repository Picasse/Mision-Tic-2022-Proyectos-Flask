from os import system
system("cls")

lista=[1,2.5,"Uninorte",4, True]

for elemento in lista:
    print(elemento)


for i in range(len(lista)):
    print(lista[i])


