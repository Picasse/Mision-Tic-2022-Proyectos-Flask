from os import system
system("cls")

def pares(n):
    listapares=[]
    for i in range(2,n+1,2):
        listapares.append(i)     
    return listapares


def imprimirLista(lista):
    for i in lista:
        print(i)


def principal():
    n=int(input("Digite el valor hasta donde se recorrerá: "))
    listaPar=pares(n)
    imprimirLista(listaPar)

principal()