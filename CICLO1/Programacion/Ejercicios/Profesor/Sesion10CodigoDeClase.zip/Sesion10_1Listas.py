
lista=[1,3,5,6,7,8,9,10]

print(lista[0]) #Imprime el primer elemento de la lista
print(lista[-1]) #Imprime el ultimo elemento de la lista
print(lista[2])
print(lista[-2])
print(lista)

listaVacia=[]
print(listaVacia)

nombre="Pepe"
edad=25
datos=[nombre, edad]
print(datos)



