from os import system
system("cls")
# Append
datos=[8,9,15]
datos.append(20)
print(datos)

datos2=[]
datos2.append(9)
print(datos2)

#Insert
datos.insert(1,20)
print(datos)
datos[2]=25
print(datos)

#Clear
datos.clear()
print(datos)

datos=[8,9,15,9]
#Remove
datos.remove(9)
print(datos)

#Index
print(datos.index(15))

#pop
datos.pop()
print(datos)

#len
print(len(datos))

#borrar dado un indice 1
datos.remove(datos[1])
print(datos)