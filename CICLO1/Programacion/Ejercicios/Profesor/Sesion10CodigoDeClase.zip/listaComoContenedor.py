#Realizar una función que reciba una lista 
#y diga cuanots son paraes, impares o cero

def contadora(lista):
    contPares=0
    contImpares=0
    contCeros=0    
    for elemento in lista:
        if elemento==0:
            contCeros+=1
        elif elemento%2==0:
            contPares+=1
        else:
            contImpares+=1
    
    return contCeros, contPares, contImpares

miLista=[2,3,0,12,10,9,0,0,4]

result=contadora(miLista)

print(f"La cantidad de ceros es: {result[0]}")
print(f"La cantidad de Pares es: {result[1]}")
print(f"La cantidad de Impares es: {result[2]}")
   
    