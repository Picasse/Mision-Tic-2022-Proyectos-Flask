# lista1=[1,2,3]
# lista2=[7,8,9]
# lista1.extend(lista2)
#print(lista1)
from os import system
system("cls")

listaimpar=[]
listapar=[]
listaimpar.extend(range(1,100,2))
listapar.extend(range(2,101,2))

print(listaimpar)
print()
print(listapar)
