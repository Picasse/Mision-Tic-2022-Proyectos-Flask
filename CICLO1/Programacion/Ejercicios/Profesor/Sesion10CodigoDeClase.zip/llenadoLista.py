#Llenar una lista con numeros pares y otra con
#numeros impares del 1 al 100

listaPar=[]
listaImpar=[]

for i in range(1,101):
    if (i%2==0):
        listaPar.append(i)
    else:
        listaImpar.append(i)

print(listaPar)
print()
print(listaImpar)


